public class Test {
    public static void main(String[] args) {
        Student2 student = new Student2("张三", "男", 20, "计算机科学", 0, null);
        Teacher teacher = new Teacher("李老师", "女", 35, "计算机科学", 0, null);

        System.out.println("学生信息: " + student);
        student.action();

        System.out.println("老师信息: " + teacher);
        teacher.action();
    }
}