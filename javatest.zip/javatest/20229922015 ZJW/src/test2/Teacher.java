public class Teacher extends Person {
    private String major;

    public Teacher(String name, String sex, int age, String hobby, double height, String major) {
        super(name, sex, age, hobby, height);
        this.major = major;
    }

    @Override
    public void action() {
        System.out.println("老师会教学");
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "name='" + getName() + '\'' +
                ", sex='" + getSex() + '\'' +
                ", age=" + getAge() +
                ", hobby='" + getHobby() + '\'' +
                ", height=" + getHeight() +
                ", major='" + major + '\'' +
                '}';
    }
}