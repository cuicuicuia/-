public class Student2 extends Person {
    private String className;

    public Student2(String name, String sex, int age, String hobby, double height, String className) {
        super(name, sex, age, hobby, height);
        this.className = className;
    }

    @Override
    public void action() {
        System.out.println("学生会学习");
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    @Override
    public String toString() {
        return "Student{" +
                "className='" + className + '\'' +
                ", name='" + getName() + '\'' +
                ", sex='" + getSex() + '\'' +
                ", age=" + getAge() +
                ", hobby='" + getHobby() + '\'' +
                ", height=" + getHeight() +
                '}';
    }
}