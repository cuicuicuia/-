import java.util.Random;

public class Test7 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] numbers = new int[10];

        System.out.println("随机生成的10个20到100之间的正整数：");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(81) + 20; // 生成20到100之间的随机数
            System.out.println(numbers[i]);
        }
    }
}