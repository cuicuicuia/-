public class Test10 {
    public static void main(String[] args) {
        double[] scores = {8.5, 9.0, 7.8, 6.6, 8.8};
        double finalScore = calculateFinalScore(scores);
        System.out.println("小明的最终得分为: " + finalScore);
    }

    public static double calculateFinalScore(double[] scores) {
        double maxScore = scores[0];
        double minScore = scores[0];
        double totalScore = 0;

        for (double score : scores) {
            totalScore += score;
            if (score > maxScore) {
                maxScore = score;
            }
            if (score < minScore) {
                minScore = score;
            }
        }

        totalScore = totalScore - maxScore - minScore;
        return totalScore / (scores.length - 2);
    }
}