import java.util.Scanner;

public class MathDemo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("请输入第一个double类型的值: ");
        double num1 = input.nextDouble();
        
        System.out.print("请输入第二个double类型的值: ");
        double num2 = input.nextDouble();
        
        double max = Math.max(num1, num2);
        long roundedMax = Math.round(max);
        
        System.out.println("较大的数的四舍五入结果是: " + roundedMax);
        
        input.close();
    }
}