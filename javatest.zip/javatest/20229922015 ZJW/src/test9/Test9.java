public class Test9 {
    public static void main(String[] args) {
        String sentence = "The quick brown fox jumped over the lazy dog";
        System.out.println("最长单词的长度是: " + findLongestWordLength(sentence));
    }

    public static int findLongestWordLength(String sentence) {
        String[] words = sentence.split(" ");
        int maxLength = 0;

        for (String word : words) {
            if (word.length() > maxLength) {
                maxLength = word.length();
            }
        }

        return maxLength;
    }
}