public class Student1 {
    private String name;
    private int age;

    // 无参构造方法
    public Student1() {
    }

    // 带一个String类型参数的构造方法
    public Student1(String name) {
        this.name = name;
    }

    // 带两个参数的构造方法
    public Student1(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter和Setter方法
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // toString方法
    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + "}";
    }
}