import java.util.Scanner;

public class Test1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("请输入一个分数：");
        int score = input.nextInt();
        
        String grade;
        if (score >= 90 && score <= 100) {
            grade = "A级";
        } else if (score >= 80 && score < 90) {
            grade = "B级";
        } else if (score >= 70 && score < 80) {
            grade = "C级";
        } else if (score >= 60 && score < 70) {
            grade = "D级";
        } else if (score >= 0 && score < 60) {
            grade = "E级";
        } else {
            grade = "不合法";
        }
        
        System.out.println("对应的等级是：" + grade);
    }
}