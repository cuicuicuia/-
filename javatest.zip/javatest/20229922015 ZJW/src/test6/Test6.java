import java.util.ArrayList;
import java.util.List;

public class Test6 {
    public static void main(String[] args) {
        // 创建学生对象
        Student6 student1 = new Student6(1, "张三", "男", 18);
        Student6 student2 = new Student6(2, "李四", "女", 20);
        Student6 student3 = new Student6(3, "王五", "男", 22);

        // 创建学生集合
        List<Student6> studentList = new ArrayList<>();
        studentList.add(student1);
        studentList.add(student2);
        studentList.add(student3);

        // 计算总人数
        int totalStudents = studentList.size();
        System.out.println("学生总人数: " + totalStudents);

        // 计算平均年龄
        int totalAge = 0;
        for (Student6 student : studentList) {
            totalAge += student.getAge();
        }
        double averageAge = (double) totalAge / totalStudents;
        System.out.println("学生平均年龄: " + averageAge);

        // 修改张三的年龄
        student1.setAge(19);
        System.out.println("张三的年龄已修改为: " + student1.getAge());
    }
}