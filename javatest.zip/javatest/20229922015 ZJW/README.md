# work学号 项目说明

该项目是《Java程序设计》课程的期末考查作业，包含多个Java程序，旨在展示对Java编程语言的理解和应用。项目结构如下：

## 项目结构

```
work学号
├── src
│   ├── test1
│   │   └── Test1.java          // 根据输入的分数判断等级
│   ├── test2
│   │   ├── Person.java         // 定义Person类
│   │   ├── Student.java        // 定义Student类，继承自Person
│   │   ├── Teacher.java        // 定义Teacher类，继承自Person
│   │   └── Test.java           // 测试类，创建Student和Teacher对象
│   ├── test3
│   │   └── Student.java        // 定义Student类，包含成员变量和构造方法
│   ├── test4
│   │   └── Test4.java          // 打印99乘法表
│   ├── test5
│   │   └── Test5.java          // 计算1到n的和
│   ├── test6
│   │   ├── Student.java        // 定义学生类
│   │   └── Test6.java          // 测试类，处理学生对象集合
│   ├── test7
│   │   └── Test7.java          // 随机生成10个整数
│   ├── test8
│   │   └── MathDemo.java       // 比较两个double值并输出结果
│   ├── test9
│   │   └── Test9.java          // 找出最长单词的长度
│   └── test10
│       └── Test10.java         // 计算小明的最终得分
├── .idea                       // IntelliJ IDEA项目配置文件
├── work学号.iml               // IntelliJ IDEA模块文件
└── README.md                   // 项目文档说明
```

## 使用说明

1. 请确保使用Java 1.8及以上版本。
2. 使用IntelliJ IDEA打开项目。
3. 根据需要运行各个测试类以验证功能实现。

## 贡献

该项目由滇池学院22级计算机科学与技术专业的学生独立完成。请勿抄袭或复制他人代码。